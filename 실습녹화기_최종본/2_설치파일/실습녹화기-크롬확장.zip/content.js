"use strict";
(() => {
  // ../shared/src/keys.ts
  var MODIFIER_KEYS = /* @__PURE__ */ new Set(["Control", "Meta", "Alt", "Shift", "AltGraph", "CapsLock", "Fn", "OS"]);
  var KEY_ALIASES = {
    " ": "Space",
    Esc: "Escape",
    Del: "Delete",
    Return: "Enter",
    Left: "ArrowLeft",
    Right: "ArrowRight",
    Up: "ArrowUp",
    Down: "ArrowDown"
  };
  function baseKeyName(press) {
    if (press.code?.startsWith("Key"))
      return press.code.slice(3);
    if (press.code?.startsWith("Digit"))
      return press.code.slice(5);
    const key = KEY_ALIASES[press.key] ?? press.key;
    return key.length === 1 ? key.toUpperCase() : key;
  }
  function formatKeyCombo(press) {
    if (MODIFIER_KEYS.has(press.key))
      return null;
    const parts = [];
    if (press.ctrlKey || press.metaKey)
      parts.push("Ctrl");
    if (press.altKey)
      parts.push("Alt");
    if (press.shiftKey)
      parts.push("Shift");
    parts.push(baseKeyName(press));
    return parts.join("+");
  }

  // src/content.ts
  var QUIET_MS = 400;
  var MAX_WAIT_MS = 2e3;
  var DOUBLE_CLICK_MS = 400;
  var DRAG_THRESHOLD_PX = 12;
  var INTERACTIVE = [
    "a[href]",
    "button",
    "input",
    "select",
    "textarea",
    "summary",
    "label",
    "[role=button]",
    "[role=link]",
    "[role=tab]",
    "[role=menuitem]",
    "[role=option]",
    "[role=checkbox]",
    "[role=radio]",
    "[role=switch]",
    "[role=treeitem]",
    "[onclick]",
    '[tabindex]:not([tabindex="-1"])',
    "[contenteditable]:not([contenteditable=false])",
    "[draggable=true]"
  ].join(",");
  var FIELD = "input, textarea, [contenteditable]:not([contenteditable=false])";
  var NON_TEXT_INPUT = /* @__PURE__ */ new Set(["button", "submit", "reset", "checkbox", "radio", "range", "color", "hidden", "image", "file"]);
  var AVATAR = "img[class*=avatar i], img[alt*=profile i], img[alt*=\uD504\uB85C\uD544], [class*=avatar i], [class*=profile-photo i]";
  var PII_PATTERNS = [
    /[\w.+-]+@[\w-]+(\.[\w-]+)+/g,
    /01[016789][-.\s]?\d{3,4}[-.\s]?\d{4}/g,
    /\b0\d{1,2}-\d{3,4}-\d{4}\b/g,
    /\b\d{6}[-\s]?[1-4]\d{6}\b/g,
    /\b\d{4}[-\s]\d{4}[-\s]\d{4}[-\s]\d{4}\b/g
  ];
  var looksSensitive = (text) => PII_PATTERNS.some((p) => {
    p.lastIndex = 0;
    return p.test(text);
  }) || /\d{5,}/.test(text);
  function viewport() {
    return { width: window.innerWidth, height: window.innerHeight, dpr: window.devicePixelRatio || 1 };
  }
  function normalize(r, pad = 0) {
    const vw = window.innerWidth, vh = window.innerHeight;
    const left = Math.max(0, r.left - pad), top = Math.max(0, r.top - pad);
    const right = Math.min(vw, r.right + pad), bottom = Math.min(vh, r.bottom + pad);
    if (right <= left || bottom <= top)
      return null;
    return [left / vw, top / vh, (right - left) / vw, (bottom - top) / vh];
  }
  function isVisible(el) {
    const style = getComputedStyle(el);
    return style.visibility !== "hidden" && style.display !== "none" && Number(style.opacity) > 0.05;
  }
  function detectSensitiveRects() {
    const rects = [];
    const push = (r) => {
      const n = normalize(r, 2);
      if (n && rects.length < 80)
        rects.push(n);
    };
    document.querySelectorAll(FIELD).forEach((el) => {
      if (el instanceof HTMLInputElement) {
        if (NON_TEXT_INPUT.has(el.type))
          return;
        if (el.type !== "password" && !el.value)
          return;
      } else if (el instanceof HTMLTextAreaElement) {
        if (!el.value)
          return;
      } else if (!el.textContent?.trim()) {
        return;
      }
      if (isVisible(el))
        push(el.getBoundingClientRect());
    });
    document.querySelectorAll(AVATAR).forEach((el) => {
      if (isVisible(el))
        push(el.getBoundingClientRect());
    });
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode: (n) => n.parentElement?.closest("script,style,noscript,textarea") ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT
    });
    let visited = 0;
    for (let node = walker.nextNode(); node && visited < 4e3; node = walker.nextNode(), visited++) {
      const text = node.nodeValue ?? "";
      if (text.length < 6)
        continue;
      for (const pattern of PII_PATTERNS) {
        pattern.lastIndex = 0;
        for (let m = pattern.exec(text); m; m = pattern.exec(text)) {
          const range = document.createRange();
          range.setStart(node, m.index);
          range.setEnd(node, m.index + m[0].length);
          for (const r of Array.from(range.getClientRects()))
            push(r);
        }
      }
    }
    return rects;
  }
  function describe(el) {
    const info = { tagName: el.tagName };
    const role = el.getAttribute("role");
    if (role)
      info.role = role.slice(0, 20);
    const field = el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement ? el : null;
    const raw = el.getAttribute("aria-label") || (field ? field.labels?.[0]?.innerText || field.placeholder : el.innerText) || el.getAttribute("title") || "";
    const label = raw.replace(/\s+/g, " ").trim().slice(0, 40);
    if (label && !looksSensitive(label))
      info.label = label;
    return info;
  }
  function isTextField(el) {
    if (el instanceof HTMLInputElement)
      return !NON_TEXT_INPUT.has(el.type);
    return el instanceof HTMLTextAreaElement || el instanceof HTMLElement && el.isContentEditable;
  }
  function shortcutOf(e) {
    if (e.isComposing || e.repeat)
      return null;
    const combo = formatKeyCombo(e);
    if (!combo)
      return null;
    if (e.ctrlKey || e.metaKey || e.altKey)
      return combo;
    if (e.key === "Enter" && e.target instanceof HTMLTextAreaElement)
      return null;
    if (/^(Enter|Escape|Delete|F\d{1,2})$/.test(e.key))
      return combo;
    return null;
  }
  function resolveTarget(e) {
    const origin = e.composedPath()[0];
    if (!(origin instanceof Element))
      return null;
    const interactive = origin.closest(INTERACTIVE);
    if (interactive) {
      const r = interactive.getBoundingClientRect();
      if (r.width * r.height < window.innerWidth * window.innerHeight * 0.5)
        return interactive;
    }
    return origin;
  }
  function start() {
    let seq = 0;
    let settledSeq = -1;
    let firstChangeAt = 0;
    let timer;
    const send = (msg) => chrome.runtime.sendMessage(msg).catch(() => {
    });
    const settle = () => {
      firstChangeAt = 0;
      settledSeq = seq;
      send({ action: "PAGE_SETTLED", seq, viewport: viewport(), suggestedMasks: detectSensitiveRects() });
    };
    const changed = () => {
      seq++;
      const now = performance.now();
      if (!firstChangeAt)
        firstChangeAt = now;
      clearTimeout(timer);
      timer = setTimeout(settle, Math.max(0, Math.min(QUIET_MS, MAX_WAIT_MS - (now - firstChangeAt))));
    };
    let down = null;
    let pendingClick = null;
    let pendingField = null;
    const typedFields = /* @__PURE__ */ new WeakSet();
    const snapshot = (el) => {
      const rect = normalize(el.getBoundingClientRect());
      if (!rect)
        return null;
      return { frameSeq: settledSeq === seq ? seq : null, rect, target: describe(el), el, masks: detectSensitiveRects(), viewport: viewport(), at: performance.now() };
    };
    const emit = (snap, recorded) => {
      send({ action: "USER_ACTION", frameSeq: snap.frameSeq, rect: snap.rect, recorded, target: snap.target, viewport: snap.viewport, suggestedMasks: snap.masks });
    };
    const inputTypeOf = (el) => el instanceof HTMLInputElement ? el.type : el instanceof HTMLTextAreaElement ? "textarea" : "text";
    const flushPending = () => {
      if (pendingClick) {
        clearTimeout(pendingClick.timer);
        emit(pendingClick.snap, { kind: "click" });
        pendingClick = null;
      }
      if (pendingField) {
        emit(pendingField, { kind: "click" });
        pendingField = null;
      }
    };
    const dropRect = (x, y) => {
      const el = document.elementFromPoint(x, y);
      const target = el?.closest(INTERACTIVE) ?? el;
      const r = target?.getBoundingClientRect();
      const small = r && r.width * r.height < window.innerWidth * window.innerHeight * 0.25 ? normalize(r) : null;
      return small ?? normalize(new DOMRect(x - 24, y - 24, 48, 48));
    };
    const onPointerDown = (e) => {
      if (!e.isTrusted || !e.isPrimary)
        return;
      const el = resolveTarget(e);
      if (!el)
        return;
      const sameAsPendingClick = pendingClick?.snap.el === el && performance.now() - pendingClick.snap.at < DOUBLE_CLICK_MS * 1.5;
      if (!sameAsPendingClick && pendingField?.el !== el)
        flushPending();
      if (e.button === 2) {
        const snap2 = snapshot(el);
        if (snap2)
          emit(snap2, { kind: "right" });
        return;
      }
      if (e.button !== 0)
        return;
      const snap = snapshot(el);
      down = snap && { ...snap, x: e.clientX, y: e.clientY, moved: false, dragging: false };
    };
    const onPointerMove = (e) => {
      if (down && !down.moved && Math.hypot(e.clientX - down.x, e.clientY - down.y) > DRAG_THRESHOLD_PX)
        down.moved = true;
    };
    const onPointerUp = (e) => {
      if (!down || down.dragging)
        return;
      const d = down;
      down = null;
      if (d.moved) {
        emit(d, { kind: "drag", to: dropRect(e.clientX, e.clientY) });
        return;
      }
      if (isTextField(d.el)) {
        pendingField = d;
        return;
      }
      if (pendingClick && pendingClick.snap.el === d.el) {
        clearTimeout(pendingClick.timer);
        emit(pendingClick.snap, { kind: "double" });
        pendingClick = null;
        return;
      }
      const timer2 = setTimeout(() => {
        if (pendingClick) {
          emit(pendingClick.snap, { kind: "click" });
          pendingClick = null;
        }
      }, DOUBLE_CLICK_MS);
      pendingClick = { snap: d, timer: timer2 };
    };
    const onPointerCancel = () => {
      if (down)
        down.dragging = true;
    };
    const onDrop = (e) => {
      if (!down)
        return;
      const d = down;
      down = null;
      emit(d, { kind: "drag", to: dropRect(e.clientX, e.clientY) });
    };
    const onDragEnd = () => {
      if (down?.dragging)
        down = null;
    };
    const onInput = (e) => {
      if (!e.isTrusted)
        return;
      const el = resolveTarget(e);
      if (!el || !isTextField(el) || typedFields.has(el))
        return;
      typedFields.add(el);
      if (pendingField?.el === el) {
        emit(pendingField, { kind: "type", inputType: inputTypeOf(el) });
        pendingField = null;
        return;
      }
      flushPending();
      const snap = snapshot(el);
      if (snap)
        emit(snap, { kind: "type", inputType: inputTypeOf(el) });
    };
    const onFocusOut = (e) => {
      if (e.target instanceof Element)
        typedFields.delete(e.target);
    };
    const onKeyDown = (e) => {
      if (!e.isTrusted)
        return;
      const keys = shortcutOf(e);
      if (!keys)
        return;
      flushPending();
      emit({ frameSeq: settledSeq === seq ? seq : null, rect: null, target: { tagName: "KEY" }, masks: detectSensitiveRects(), viewport: viewport() }, { kind: "key", keys });
    };
    const onVisibility = () => {
      if (document.visibilityState === "visible")
        changed();
    };
    const observer = new MutationObserver(changed);
    observer.observe(document.documentElement, { subtree: true, childList: true, attributes: true, characterData: true });
    const listeners = [
      [document, "pointerdown", onPointerDown],
      [document, "pointermove", onPointerMove],
      [document, "pointerup", onPointerUp],
      [document, "pointercancel", onPointerCancel],
      [document, "drop", onDrop],
      [document, "dragend", onDragEnd],
      [document, "input", onInput],
      [document, "focusout", onFocusOut],
      [document, "keydown", onKeyDown]
    ];
    for (const [t, type, fn] of listeners)
      t.addEventListener(type, fn, { capture: true });
    document.addEventListener("load", changed, { capture: true });
    window.addEventListener("scroll", changed, { capture: true, passive: true });
    window.addEventListener("resize", changed);
    document.addEventListener("visibilitychange", onVisibility);
    changed();
    const onMessage = (msg) => {
      if (msg?.action === "STOP_CONTENT")
        stop();
    };
    chrome.runtime.onMessage.addListener(onMessage);
    function stop() {
      clearTimeout(timer);
      observer.disconnect();
      flushPending();
      for (const [t, type, fn] of listeners)
        t.removeEventListener(type, fn, { capture: true });
      document.removeEventListener("load", changed, { capture: true });
      window.removeEventListener("scroll", changed, { capture: true });
      window.removeEventListener("resize", changed);
      document.removeEventListener("visibilitychange", onVisibility);
      chrome.runtime.onMessage.removeListener(onMessage);
      delete window.__walksimRecorder;
    }
    window.__walksimRecorder = { stop };
  }
  if (!window.__walksimRecorder)
    start();
})();

"use strict";
(() => {
  // src/popup.ts
  var $ = (id) => document.getElementById(id);
  var startBtn = $("start-btn");
  var stopBtn = $("stop-btn");
  var editorBtn = $("editor-btn");
  var dummyCheck = $("dummy-check");
  var statusEl = $("status");
  var currentTabId;
  function render(recordingTabId) {
    const recordingHere = recordingTabId !== null && recordingTabId === currentTabId;
    startBtn.hidden = recordingHere;
    stopBtn.hidden = !recordingHere;
    $("prep").hidden = recordingHere;
    startBtn.disabled = !dummyCheck.checked;
    startBtn.textContent = recordingTabId !== null && !recordingHere ? "\uC774 \uD0ED\uC73C\uB85C \uB179\uD654 \uC62E\uAE30\uAE30" : "\uC774 \uD0ED \uB179\uD654 \uC2DC\uC791";
    statusEl.textContent = recordingHere ? "\u25CF \uB179\uD654 \uC911 \u2014 \uD654\uBA74\uC744 \uD074\uB9AD\uD558\uBA74 \uC5D0\uB514\uD130 \uAC80\uC218\uD568\uC73C\uB85C \uC804\uB2EC\uB429\uB2C8\uB2E4." : "";
  }
  async function refresh() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    currentTabId = tab?.id;
    const state = await chrome.runtime.sendMessage({ action: "GET_STATE" });
    render(state?.recordingTabId ?? null);
  }
  dummyCheck.addEventListener("change", () => {
    startBtn.disabled = !dummyCheck.checked;
  });
  startBtn.addEventListener("click", async () => {
    if (currentTabId === void 0)
      return;
    statusEl.textContent = "\uC2DC\uC791\uD558\uB294 \uC911\u2026";
    const res = await chrome.runtime.sendMessage({ action: "START_RECORDING", tabId: currentTabId });
    if (!res?.ok) {
      statusEl.textContent = res?.error ?? "\uB179\uD654\uB97C \uC2DC\uC791\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.";
      return;
    }
    await refresh();
  });
  stopBtn.addEventListener("click", async () => {
    statusEl.textContent = "\uB9C8\uC9C0\uB9C9 \uD654\uBA74\uC744 \uCEA1\uCC98\uD558\uB294 \uC911\u2026";
    await chrome.runtime.sendMessage({ action: "STOP_RECORDING" });
    await refresh();
    statusEl.textContent = "\uB179\uD654\uB97C \uB9C8\uCCE4\uC2B5\uB2C8\uB2E4. \uC5D0\uB514\uD130 \uAC80\uC218\uD568\uC5D0\uC11C \uD655\uC778\uD558\uC138\uC694.";
  });
  editorBtn.addEventListener("click", () => chrome.runtime.sendMessage({ action: "OPEN_EDITOR" }));
  void refresh();
})();

// src/messages.ts
var EDITOR_PATH = "editor/index.html";

// src/background.ts
var MIN_CAPTURE_GAP_MS = 550;
var EDITOR_URL = chrome.runtime.getURL(EDITOR_PATH);
var MAX_FRAMES = 6;
var frames = [];
var latestFrame = (tabId) => [...frames].reverse().find((f) => f.tabId === tabId) ?? null;
var missedSettle = null;
var captureChain = Promise.resolve();
var lastCaptureAt = 0;
var pending = [];
var getState = () => chrome.storage.session.get(["recordingTabId", "devEditorTabId"]);
var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function setBadge(tabId, text, color = "#dc2626") {
  chrome.action.setBadgeText({ text, tabId }).catch(() => {
  });
  chrome.action.setBadgeBackgroundColor({ color, tabId }).catch(() => {
  });
}
function captureTab(tabId) {
  const run = async () => {
    const wait = MIN_CAPTURE_GAP_MS - (Date.now() - lastCaptureAt);
    if (wait > 0)
      await sleep(wait);
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    if (!tab?.active)
      return null;
    lastCaptureAt = Date.now();
    try {
      return await chrome.tabs.captureVisibleTab(tab.windowId, { format: "jpeg", quality: 92 });
    } catch (err) {
      console.warn("\uCEA1\uCC98 \uC2E4\uD328:", err);
      setBadge(tabId, "!");
      return null;
    }
  };
  const result = captureChain.then(run);
  captureChain = result.catch(() => {
  });
  return result;
}
async function findEditorTab() {
  const contexts = await chrome.runtime.getContexts({ contextTypes: [chrome.runtime.ContextType.TAB] });
  return contexts.find((c) => c.documentUrl?.startsWith(EDITOR_URL))?.tabId;
}
async function openEditor(focus) {
  const tabId = await findEditorTab();
  if (tabId !== void 0 && tabId >= 0) {
    if (focus) {
      const tab = await chrome.tabs.update(tabId, { active: true });
      if (tab?.windowId !== void 0)
        await chrome.windows.update(tab.windowId, { focused: true });
    }
    return;
  }
  await chrome.tabs.create({ url: EDITOR_URL, active: focus });
}
async function sendToEditor(payload) {
  try {
    const res = await chrome.runtime.sendMessage({ action: "NEW_CAPTURE", payload });
    if (res?.received)
      return true;
  } catch {
  }
  const { devEditorTabId } = await getState();
  if (typeof devEditorTabId === "number") {
    try {
      const res = await chrome.tabs.sendMessage(devEditorTabId, { action: "NEW_CAPTURE", payload });
      if (res?.received)
        return true;
    } catch {
      await chrome.storage.session.remove("devEditorTabId");
    }
  }
  return false;
}
async function deliver(payload) {
  if (pending.length === 0 && await sendToEditor(payload))
    return;
  pending.push(payload);
  await openEditor(false);
}
async function flushPending() {
  while (pending.length > 0) {
    if (!await sendToEditor(pending[0]))
      return;
    pending.shift();
  }
}
async function injectRecorder(tabId) {
  await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
}
async function startRecording(tabId) {
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  if (!tab?.url?.startsWith("http") && tab?.url !== void 0) {
    return { ok: false, error: "\uC77C\uBC18 \uC6F9\uD398\uC774\uC9C0(http/https)\uC5D0\uC11C\uB9CC \uB179\uD654\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4." };
  }
  try {
    await injectRecorder(tabId);
  } catch (err) {
    return { ok: false, error: `\uC774 \uD398\uC774\uC9C0\uC5D0\uB294 \uB179\uD654\uAE30\uB97C \uB123\uC744 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4. (${err.message})` };
  }
  await chrome.storage.session.set({ recordingTabId: tabId });
  frames = [];
  setBadge(tabId, "REC");
  await openEditor(false);
  return { ok: true };
}
async function stopRecording() {
  const { recordingTabId } = await getState();
  await chrome.storage.session.remove("recordingTabId");
  if (recordingTabId === void 0)
    return;
  setBadge(recordingTabId, "");
  chrome.tabs.sendMessage(recordingTabId, { action: "STOP_CONTENT" }).catch(() => {
  });
  const last = latestFrame(recordingTabId);
  const image = await captureTab(recordingTabId) ?? last?.image ?? null;
  frames = [];
  if (image && last) {
    await deliver({ image, rect: null, viewport: last.viewport, target: null, suggestedMasks: last.suggestedMasks, action: null, timestamp: Date.now() });
  }
}
async function onPageSettled(tabId, msg) {
  const image = await captureTab(tabId);
  if (image) {
    frames = [...frames.filter((f) => !(f.tabId === tabId && f.seq === msg.seq)), { tabId, seq: msg.seq, image, viewport: msg.viewport, suggestedMasks: msg.suggestedMasks }].slice(-MAX_FRAMES);
    missedSettle = null;
  } else {
    missedSettle = { tabId, msg };
  }
}
async function onUserAction(tabId, msg) {
  const fresh = msg.frameSeq === null ? null : frames.find((f) => f.tabId === tabId && f.seq === msg.frameSeq) ?? null;
  const image = fresh?.image ?? await captureTab(tabId);
  if (!image)
    return;
  await deliver({
    image,
    rect: msg.rect,
    viewport: msg.viewport,
    target: msg.target,
    suggestedMasks: fresh?.suggestedMasks ?? msg.suggestedMasks,
    action: msg.recorded,
    timestamp: Date.now()
  });
}
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id)
    return;
  const fromTab = sender.tab?.id;
  switch (msg?.action) {
    case "START_RECORDING":
      startRecording(msg.tabId).then(sendResponse);
      return true;
    case "STOP_RECORDING":
      stopRecording().then(() => sendResponse({ ok: true }));
      return true;
    case "GET_STATE":
      getState().then((s) => sendResponse({ recordingTabId: s.recordingTabId ?? null }));
      return true;
    case "OPEN_EDITOR":
      openEditor(true).then(() => sendResponse({ ok: true }));
      return true;
    case "EDITOR_READY":
      if (!sender.url?.startsWith(EDITOR_URL) && fromTab !== void 0) {
        chrome.storage.session.set({ devEditorTabId: fromTab });
      }
      void flushPending();
      return;
    case "PAGE_SETTLED":
    case "USER_ACTION":
      getState().then(({ recordingTabId }) => {
        if (fromTab === void 0 || fromTab !== recordingTabId)
          return;
        if (msg.action === "PAGE_SETTLED")
          void onPageSettled(fromTab, msg);
        else
          void onUserAction(fromTab, msg);
      });
      return;
  }
});
chrome.tabs.onUpdated.addListener(async (tabId, info) => {
  const { recordingTabId } = await getState();
  if (tabId !== recordingTabId)
    return;
  if (info.status === "loading") {
    frames = frames.filter((f) => f.tabId !== tabId);
    if (missedSettle?.tabId === tabId)
      missedSettle = null;
  }
  if (info.status === "complete") {
    try {
      await injectRecorder(tabId);
      setBadge(tabId, "REC");
    } catch {
      setBadge(tabId, "!");
      chrome.action.setTitle({ tabId, title: "\uC2E4\uC2B5 \uB179\uD654\uAE30: \uD398\uC774\uC9C0\uAC00 \uBC14\uB00C\uC5B4 \uB179\uD654\uAC00 \uBA48\uCDC4\uC2B5\uB2C8\uB2E4. \uC544\uC774\uCF58\uC744 \uB20C\uB7EC \uACC4\uC18D\uD558\uC138\uC694." }).catch(() => {
      });
    }
  }
});
chrome.tabs.onActivated.addListener(({ tabId }) => {
  if (missedSettle?.tabId === tabId)
    void onPageSettled(tabId, missedSettle.msg);
});
chrome.tabs.onRemoved.addListener(async (tabId) => {
  const { recordingTabId, devEditorTabId } = await getState();
  if (tabId === recordingTabId) {
    await chrome.storage.session.remove("recordingTabId");
    frames = [];
  }
  if (tabId === devEditorTabId)
    await chrome.storage.session.remove("devEditorTabId");
});

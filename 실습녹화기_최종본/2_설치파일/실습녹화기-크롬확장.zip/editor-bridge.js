"use strict";
(() => {
  // src/editor-bridge.ts
  if (document.querySelector('meta[name="walksim-editor"]')) {
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      if (sender.id !== chrome.runtime.id || request?.action !== "NEW_CAPTURE")
        return;
      window.postMessage({ type: "WALKSIM_NEW_CAPTURE", payload: request.payload }, location.origin);
      sendResponse({ received: true });
    });
    const announce = () => chrome.runtime.sendMessage({ action: "EDITOR_READY" }).catch(() => {
    });
    window.addEventListener("message", (event) => {
      if (event.source === window && event.origin === location.origin && event.data?.type === "WALKSIM_EDITOR_READY")
        announce();
    });
    announce();
  }
})();
